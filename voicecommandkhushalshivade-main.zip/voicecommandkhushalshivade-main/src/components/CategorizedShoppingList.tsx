import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Trash2, ShoppingCart } from "lucide-react";
import type { ShoppingItem, Category } from "@/types/shopping";

interface CategorizedShoppingListProps {
  items: ShoppingItem[];
  onRemoveItem: (id: string) => void;
}

export const CategorizedShoppingList = ({ items, onRemoveItem }: CategorizedShoppingListProps) => {
  const groupedByCategory = items.reduce((acc, item) => {
    const cat = item.category;
    if (!acc[cat]) acc[cat] = [];
    acc[cat].push(item);
    return acc;
  }, {} as Record<Category, ShoppingItem[]>);

  if (items.length === 0) {
    return (
      <Card className="p-8 text-center bg-white dark:bg-gray-800">
        <ShoppingCart className="w-16 h-16 text-indigo-400 dark:text-indigo-600 mx-auto mb-4 opacity-50" />
        <p className="text-muted-foreground text-lg">Start by saying "Add milk" or search for products</p>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      {Object.entries(groupedByCategory).map(([category, categoryItems]) => (
        <Card key={category} className="p-6 bg-white dark:bg-gray-800">
          <h3 className="text-2xl font-bold mb-4 capitalize border-b-2 border-indigo-300 dark:border-indigo-700 pb-2 flex items-center gap-2">
            <span>📦</span> {category}
          </h3>
          <div className="space-y-3">
            {categoryItems.map((item) => (
              <div
                key={item.id}
                className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-700/50 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 transition border border-indigo-200 dark:border-indigo-800"
              >
                <div className="flex items-center gap-4 flex-1">
                  <span className="text-4xl">{item.icon}</span>
                  <div>
                    <p className="font-semibold text-foreground">{item.name}</p>
                    <p className="text-sm text-muted-foreground">${item.price} each</p>
                  </div>
                </div>
                <div className="text-right mr-4">
                  <p className="font-bold text-indigo-600 dark:text-indigo-400">
                    ${(item.price * item.quantity).toFixed(2)}
                  </p>
                  <p className="text-sm text-muted-foreground">Qty: {item.quantity}</p>
                </div>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => onRemoveItem(item.id)}
                  className="hover:bg-red-50 dark:hover:bg-red-900/20 hover:text-red-500"
                >
                  <Trash2 className="w-5 h-5" />
                </Button>
              </div>
            ))}
          </div>
        </Card>
      ))}
    </div>
  );
};