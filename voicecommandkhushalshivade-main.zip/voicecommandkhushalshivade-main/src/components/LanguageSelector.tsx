import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Globe } from "lucide-react";
import type { Language } from "@/types/shopping";

interface LanguageSelectorProps {
  language: Language;
  onLanguageChange: (language: Language) => void;
}

const languages: { value: Language; label: string }[] = [
  { value: "en-US", label: "English" },
  { value: "hi-IN", label: "हिन्दी (Hindi)" },
  { value: "gu-IN", label: "ગુજરાતી (Gujarati)" },
  { value: "mr-IN", label: "मराठी (Marathi)" },
  { value: "te-IN", label: "తెలుగు (Telugu)" },
  { value: "pa-IN", label: "ਪੰਜਾਬੀ (Punjabi)" },
  { value: "en-IN", label: "English (India)" },
];

export const LanguageSelector = ({ language, onLanguageChange }: LanguageSelectorProps) => {
  return (
    <div className="flex items-center gap-2">
      <Globe className="w-5 h-5 text-muted-foreground" />
      <Select value={language} onValueChange={(value) => onLanguageChange(value as Language)}>
        <SelectTrigger className="w-[200px]">
          <SelectValue />
        </SelectTrigger>
        <SelectContent>
          {languages.map((lang) => (
            <SelectItem key={lang.value} value={lang.value}>
              {lang.label}
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  );
};