import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Plus } from "lucide-react";
import type { Product } from "@/types/shopping";

interface MainProductDisplayProps {
  product: Product;
  onAddItem: (product: Product) => void;
}

export const MainProductDisplay = ({ product, onAddItem }: MainProductDisplayProps) => {
  return (
    <Card className="bg-gradient-to-br from-indigo-100 to-blue-100 dark:from-indigo-900/30 dark:to-blue-900/30 p-8 border-2 border-indigo-400 dark:border-indigo-600">
      <div className="text-center">
        <p className="text-7xl mb-4 animate-bounce">{product.icon}</p>
        <h3 className="text-4xl font-bold text-indigo-900 dark:text-indigo-100 mb-2">{product.name}</h3>
        <p className="text-3xl font-bold text-indigo-600 dark:text-indigo-400 mb-2">${product.price}</p>
        <p className="text-indigo-700 dark:text-indigo-300 capitalize mb-6 text-lg">{product.category}</p>
        <Button
          onClick={() => onAddItem(product)}
          size="lg"
          className="bg-indigo-600 hover:bg-indigo-700 dark:bg-indigo-500 dark:hover:bg-indigo-600"
        >
          <Plus className="w-5 h-5 mr-2" /> Add to Cart
        </Button>
      </div>
    </Card>
  );
};