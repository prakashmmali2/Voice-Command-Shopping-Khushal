import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import type { Product } from "@/types/shopping";

interface RelatedProductsProps {
  products: Product[];
  onAddItem: (product: Product) => void;
}

export const RelatedProducts = ({ products, onAddItem }: RelatedProductsProps) => {
  return (
    <Card className="p-6 bg-white dark:bg-gray-800">
      <h3 className="text-2xl font-bold mb-6 flex items-center gap-2">
        <span>💡</span> Related Items
      </h3>
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
        {products.map((product) => (
          <Button
            key={product.name}
            onClick={() => onAddItem(product)}
            variant="outline"
            className="h-auto p-4 flex flex-col gap-2 bg-gradient-to-br from-amber-50 to-orange-50 dark:from-amber-900/20 dark:to-orange-900/20 hover:from-amber-100 hover:to-orange-100 dark:hover:from-amber-900/30 dark:hover:to-orange-900/30 border-2 border-amber-200 dark:border-amber-700 transform hover:scale-105 transition-all"
          >
            <div className="text-4xl mb-2">{product.icon}</div>
            <p className="font-semibold text-sm text-center">{product.name}</p>
            <p className="font-bold text-amber-600 dark:text-amber-400">${product.price}</p>
          </Button>
        ))}
      </div>
    </Card>
  );
};