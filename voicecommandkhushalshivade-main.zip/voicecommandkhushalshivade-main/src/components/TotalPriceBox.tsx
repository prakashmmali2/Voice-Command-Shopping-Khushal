import { Card } from "@/components/ui/card";
import type { ShoppingItem } from "@/types/shopping";

interface TotalPriceBoxProps {
  items: ShoppingItem[];
}

export const TotalPriceBox = ({ items }: TotalPriceBoxProps) => {
  const totalPrice = items.reduce((sum, item) =>
    sum + (item.price * item.quantity), 0
  ).toFixed(2);

  return (
    <Card className="bg-white dark:bg-gray-800 border-t-4 border-indigo-600 dark:border-indigo-400 p-6">
      <div className="flex justify-between items-center">
        <div>
          <p className="text-muted-foreground text-lg">Total Items</p>
          <p className="text-3xl font-bold text-indigo-600 dark:text-indigo-400">{items.length}</p>
        </div>
        <div className="h-12 w-1 bg-indigo-300 dark:bg-indigo-700"></div>
        <div className="text-right">
          <p className="text-muted-foreground text-lg">Total Price</p>
          <p className="text-4xl font-bold text-indigo-600 dark:text-indigo-400">${totalPrice}</p>
        </div>
      </div>
    </Card>
  );
};