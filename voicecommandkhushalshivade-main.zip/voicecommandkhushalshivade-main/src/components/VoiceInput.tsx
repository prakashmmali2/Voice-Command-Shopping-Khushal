import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Mic, MicOff, AlertCircle, Check } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { Language, Product } from "@/types/shopping";
import { parseVoiceCommand } from "@/utils/voiceParser";

interface VoiceInputProps {
  language: Language;
  onAddItem: (product: Product, quantity: number) => void;
}

declare global {
  interface Window {
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

export const VoiceInput = ({ language, onAddItem }: VoiceInputProps) => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState("");
  const [feedback, setFeedback] = useState("");
  const [recognition, setRecognition] = useState<any>(null);
  const { toast } = useToast();

  useEffect(() => {
    if (typeof window !== 'undefined' && ('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
      const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
      const recognitionInstance = new SpeechRecognition();
      recognitionInstance.continuous = false;
      recognitionInstance.interimResults = true;
      recognitionInstance.lang = language;

      recognitionInstance.onstart = () => {
        setIsListening(true);
        setTranscript('🎤 Listening...');
        setFeedback('');
      };

      recognitionInstance.onresult = (event: any) => {
        let interimTranscript = '';
        let finalTranscript = '';

        for (let i = event.resultIndex; i < event.results.length; i++) {
          const text = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            finalTranscript += text + ' ';
          } else {
            interimTranscript += text;
          }
        }

        if (interimTranscript) {
          setTranscript(`🎤 ${interimTranscript}`);
        }

        if (finalTranscript) {
          setTranscript(`✅ ${finalTranscript.trim()}`);
          processVoiceCommand(finalTranscript.trim());
        }
      };

      recognitionInstance.onerror = (event: any) => {
        console.error('Speech recognition error:', event.error);
        setIsListening(false);
        
        if (event.error === 'not-allowed') {
          setFeedback('⚠️ Microphone blocked. Check: Settings → Privacy → Microphone. Allow access to this site.');
        } else if (event.error === 'no-speech') {
          setFeedback('⚠️ No speech detected. Try again clearly.');
          setTimeout(() => setFeedback(''), 2000);
        } else {
          setFeedback(`❌ Error: ${event.error}. Refresh and try again.`);
        }
      };

      recognitionInstance.onend = () => {
        setIsListening(false);
      };

      setRecognition(recognitionInstance);
    }
  }, [language, toast]);

  const processVoiceCommand = (command: string) => {
    const result = parseVoiceCommand(command, language);
    
    if (result) {
      onAddItem(result.product, result.quantity);
      setFeedback(`✅ Added ${result.product.name}`);
      setTranscript('');
      setTimeout(() => setFeedback(''), 2000);
    } else {
      setFeedback('❌ Product not found. Try: "Add milk" or "I need bread"');
      setTimeout(() => setFeedback(''), 3000);
    }
  };

  const toggleListening = () => {
    if (!recognition) {
      toast({
        title: "Not Supported",
        description: "Voice recognition is not supported in your browser",
        variant: "destructive",
      });
      return;
    }

    if (isListening) {
      recognition.stop();
      setIsListening(false);
    } else {
      recognition.lang = language;
      recognition.start();
      setIsListening(true);
    }
  };

  return (
    <div className="space-y-4">
      <Button
        onClick={toggleListening}
        size="lg"
        className={`w-full h-14 font-bold text-white transition flex items-center justify-center gap-2 ${
          isListening
            ? 'bg-red-500 hover:bg-red-600 animate-pulse'
            : 'bg-indigo-600 hover:bg-indigo-700'
        }`}
      >
        {isListening ? <MicOff className="w-5 h-5" /> : <Mic className="w-5 h-5" />}
        {isListening ? 'Stop Listening' : 'Start Listening'}
      </Button>

      {transcript && (
        <div className="bg-blue-50 dark:bg-blue-900/20 border-l-4 border-blue-400 dark:border-blue-600 p-3 rounded text-sm text-blue-800 dark:text-blue-200">
          {transcript}
        </div>
      )}

      {feedback && (
        <div className={`p-3 rounded-lg flex items-center gap-2 text-sm border-l-4 ${
          feedback.includes('❌') || feedback.includes('⚠️')
            ? 'bg-red-50 dark:bg-red-900/20 text-red-800 dark:text-red-200 border-red-400 dark:border-red-600'
            : 'bg-green-50 dark:bg-green-900/20 text-green-800 dark:text-green-200 border-green-400 dark:border-green-600'
        }`}>
          {feedback.includes('❌') || feedback.includes('⚠️') ? 
            <AlertCircle className="w-4 h-4" /> : 
            <Check className="w-4 h-4" />
          }
          {feedback}
        </div>
      )}
    </div>
  );
};