import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { ShoppingCart } from "lucide-react";
import { VoiceInput } from "@/components/VoiceInput";
import { SearchBar } from "@/components/SearchBar";
import { MainProductDisplay } from "@/components/MainProductDisplay";
import { RelatedProducts } from "@/components/RelatedProducts";
import { CategorizedShoppingList } from "@/components/CategorizedShoppingList";
import { TotalPriceBox } from "@/components/TotalPriceBox";
import { LanguageSelector } from "@/components/LanguageSelector";
import type { ShoppingItem, Language, Product } from "@/types/shopping";
import { availableProducts } from "@/data/products";

const Index = () => {
  const [shoppingList, setShoppingList] = useState<ShoppingItem[]>([]);
  const [language, setLanguage] = useState<Language>("en-US");
  const [mainProduct, setMainProduct] = useState<Product | null>(null);
  const [relatedProducts, setRelatedProducts] = useState<Product[]>([]);
  const [searchInput, setSearchInput] = useState("");
  const { toast } = useToast();

  const addItem = (product: Product, quantity: number = 1) => {
    const existingItem = shoppingList.find(item => item.name === product.name);

    if (existingItem) {
      setShoppingList(shoppingList.map(item =>
        item.name === product.name
          ? { ...item, quantity: item.quantity + quantity }
          : item
      ));
      toast({
        title: "✅ Updated",
        description: `${product.name} (Qty: ${existingItem.quantity + quantity})`,
      });
    } else {
      const newItem: ShoppingItem = {
        id: Date.now().toString(),
        name: product.name,
        category: product.category,
        quantity,
        price: product.price,
        icon: product.icon,
        addedAt: new Date(),
      };
      setShoppingList([...shoppingList, newItem]);
      toast({
        title: "✅ Added",
        description: `${product.name} to your cart`,
      });
    }

    setMainProduct(product);
    if (product.relatedItems && product.relatedItems.length > 0) {
      const relProds = product.relatedItems
        .map(name => availableProducts.find(p => p.name === name))
        .filter(Boolean) as Product[];
      setRelatedProducts(relProds);
    }
  };

  const removeItem = (id: string) => {
    const item = shoppingList.find(i => i.id === id);
    setShoppingList(prev => prev.filter(i => i.id !== id));
    if (item) {
      toast({
        title: "✅ Removed",
        description: `${item.name} from your cart`,
      });
    }
  };

  const handleSearchChange = (value: string) => {
    setSearchInput(value);
    if (value.trim()) {
      const product = availableProducts.find(p => 
        p.name.toLowerCase().includes(value.toLowerCase())
      );
      if (product) {
        setMainProduct(product);
        const relProds = (product.relatedItems || [])
          .map(name => availableProducts.find(p => p.name === name))
          .filter(Boolean) as Product[];
        setRelatedProducts(relProds);
      }
    } else {
      setMainProduct(null);
      setRelatedProducts([]);
    }
  };

  const clearSearch = () => {
    setSearchInput("");
    setMainProduct(null);
    setRelatedProducts([]);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 dark:from-gray-900 dark:via-blue-950 dark:to-indigo-950">
      <div className="container mx-auto px-4 py-8 max-w-7xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center gap-3 mb-4">
            <ShoppingCart className="w-10 h-10 text-indigo-600 dark:text-indigo-400" />
            <h1 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 dark:from-indigo-400 dark:to-purple-400 bg-clip-text text-transparent">
              Voice Shopping Assistant
            </h1>
          </div>
          <p className="text-muted-foreground">Say "Add milk" or search for products</p>
        </div>

        {/* Language Selector */}
        <div className="flex justify-center mb-6">
          <LanguageSelector language={language} onLanguageChange={setLanguage} />
        </div>

        {/* Search & Voice Input */}
        <div className="bg-white dark:bg-gray-800 rounded-lg shadow-lg p-6 mb-8">
          <div className="space-y-4">
            <VoiceInput language={language} onAddItem={addItem} />
            <SearchBar 
              value={searchInput}
              onChange={handleSearchChange}
              onClear={clearSearch}
            />
          </div>
        </div>

        {/* Main Content */}
        <div className="space-y-8">
          {/* Main Product Display */}
          {mainProduct && (
            <MainProductDisplay product={mainProduct} onAddItem={addItem} />
          )}

          {/* Related Products */}
          {relatedProducts.length > 0 && (
            <RelatedProducts products={relatedProducts} onAddItem={addItem} />
          )}

          {/* Categorized Shopping List */}
          <CategorizedShoppingList items={shoppingList} onRemoveItem={removeItem} />

          {/* Total Price Box */}
          {shoppingList.length > 0 && <TotalPriceBox items={shoppingList} />}
        </div>
      </div>
    </div>
  );
};

export default Index;