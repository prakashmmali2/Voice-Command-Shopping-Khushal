export type Language = "en-US" | "hi-IN" | "gu-IN" | "mr-IN" | "te-IN" | "pa-IN" | "en-IN";

export type Category = 
  | "Food & Beverages"
  | "Clothing & Apparel"
  | "Home Decor"
  | "Home Appliances"
  | "Electronics & Gadgets"
  | "Study Materials"
  | "Sports Items"
  | "Personal Care"
  | "Other";

export interface ShoppingItem {
  id: string;
  name: string;
  category: Category;
  quantity: number;
  price: number;
  icon: string;
  addedAt: Date;
}

export interface Product {
  name: string;
  category: Category;
  icon: string;
  price: number;
  relatedItems?: string[];
}