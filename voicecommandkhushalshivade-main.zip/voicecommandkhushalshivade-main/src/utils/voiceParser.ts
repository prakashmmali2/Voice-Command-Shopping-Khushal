import type { Language, Product } from "@/types/shopping";
import { availableProducts } from "@/data/products";

const removeStopwords = (text: string): string => {
  const stopwords = ['add', 'i', 'me', 'need', 'want', 'buy', 'get', 'the', 'a', 'an', 'to', 'mujhe', 'do', 'chahiye', 'le', 'lo', 'give'];
  const words = text.toLowerCase().split(/\s+/);
  return words.filter(w => !stopwords.includes(w)).join(' ');
};

export const parseVoiceCommand = (
  command: string, 
  language: Language
): { product: Product; quantity: number } | null => {
  const lowerCommand = command.toLowerCase().trim();

  // Extract quantity
  const quantityMatch = lowerCommand.match(/(\d+)\s*(bottles?|bags?|boxes?|packs?|cans?|kg|liter|litre|pieces?|quantity)?/);
  const quantity = quantityMatch ? parseInt(quantityMatch[1]) : 1;

  // Clean command
  let cleanCommand = removeStopwords(lowerCommand);
  cleanCommand = cleanCommand.replace(/(\d+)\s*(bottles?|bags?|boxes?|packs?|cans?|kg|liter|litre|pieces?|quantity)?/gi, '').trim();

  // Find product
  const product = availableProducts.find(p => 
    p.name.toLowerCase().includes(cleanCommand) ||
    cleanCommand.includes(p.name.toLowerCase()) ||
    p.name.toLowerCase().split(' ').some(word => cleanCommand.includes(word))
  );

  if (!product) return null;

  return { product, quantity };
};